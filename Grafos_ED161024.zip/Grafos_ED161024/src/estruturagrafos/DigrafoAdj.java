package estruturagrafos;
import javax.swing.JOptionPane;

public class DigrafoAdj {
    private int[][] matrizAdj;
    private int numVertices;
    private int numArestas;

    public DigrafoAdj(int nVertices) {
        // Matriz de adjacência: são matrizes nas quais as linhas e as colunas estão associadas aos vértices.
        // O elemento da linha i e coluna j é o número de arestas que têm i e j como extremidades.
        this.numVertices = nVertices;
        this.matrizAdj = new int[nVertices][nVertices];
        this.numArestas = 0;

        // Inicializar a matriz com 0
        for (int i = 0; i < nVertices; i++) {
            for (int j = 0; j < nVertices; j++) {
                this.matrizAdj[i][j] = 0;
            }
        }
    }

    public void adicionarAresta(int origem, int destino) {
        matrizAdj[origem - 1][destino - 1]++;
        numArestas++;
    }

    public int getNumArestas() {
        return this.numArestas;
    }

    public void imprimirMatrizAdjacencia() {
        StringBuilder sb = new StringBuilder("Matriz de Adjacência:\n");
        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
                sb.append(matrizAdj[i][j]).append(" ");
            }
            sb.append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public int grauEntrada(int vertice) {
        int grauEntrada = 0;
        for (int i = 0; i < numVertices; i++) {
            grauEntrada += matrizAdj[i][vertice - 1];
        }
        return grauEntrada;
    }

    public int grauSaida(int vertice) {
        int grauSaida = 0;
        for (int j = 0; j < numVertices; j++) {
            grauSaida += matrizAdj[vertice - 1][j];
        }
        return grauSaida;
    }

    public boolean digrafoSimples() {
        for (int i = 0; i < numVertices; i++) {
            for (int j=0;j<numVertices;j++){
                if ((i==j && matrizAdj[i][i] > 0) || matrizAdj[i][j] > 1) {
                    return false; // Tem laços ou arestas paralelas
                } //else { return true; }
            }
        }
        return true;
    }

    public String vizinhos(int vertice) {
        StringBuilder sb = new StringBuilder();
        for (int j = 0; j < numVertices; j++) {
            if (matrizAdj[vertice - 1][j] > 0) {
                sb.append(j + 1).append(" ");
            }
        }
        return sb.toString();
    }

    public String informarArestasParalelasELaços() {
        int loops = 0, arestasParalelas = 0;
        StringBuilder sb = new StringBuilder("Arestas paralelas e laços:\n");

        // Verificando laços e arestas paralelas
        for (int i = 0; i < numVertices; i++) { // Considera que existem laços no vértice. Mas não sabe quantos laços?
            if (matrizAdj[i][i] > 0) {
                loops++;
                sb.append("Loop no vértice ").append(i + 1).append(" (").append(matrizAdj[i][i]).append(")\n");
            }
            //
            for (int j = 0; j < numVertices; j++) {
                if (i != j && matrizAdj[i][j] > 1) {
                    arestasParalelas++;
                    sb.append("Aresta paralela entre vértices ").append(i + 1).append(" e ").append(j + 1).append(" (").append(matrizAdj[i][j]).append(")\n");
                } // ^ Existência v. Quantidade Real
            }
        }

        sb.append("Total de laços: ").append(loops).append("\n");
        sb.append("Total de arestas paralelas: ").append(arestasParalelas).append("\n");

        return sb.toString();
    }

    public String informarNumVerticesEArestas() {
        return "Número de vértices: " + numVertices + "\nNúmero de arestas: " + numArestas;
    }
}
