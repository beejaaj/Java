package estruturagrafos;
import javax.swing.JOptionPane;

// Dizemos que dois vértices são adjacentes se há uma aresta conectando eles, ao passo que uma aresta é incidente aos vértices que ela conecta.
// Multigrafos são grafos onde podemos ter arestas paralelas e laços.
// Arestas paralelas são arestas diferentes incidentes aos mesmos dois vértices.
// Laços são arestas incidentes a um mesmo vértice. Observemos que um laço contribui duas unidades para o grau do vértice.
// Chamamos grau de um vértice o número de arestas com extremidade neste vértice.
// A soma dos graus dos vértices do grafo é chamada grau do grafo.
// Grafo simples é todo grafo que não apresenta laços nem arestas paralelas.
// Grafos bipartidos são grafos nos quais o conjunto de vértices pode ser particionado em dois subconjuntos de tal maneira que vértices de um mesmo subconjunto não sejam adjacentes.
// Dígrafo é todo grafo em que as arestas têm uma orientação.

// Teorema: O grau de um grafo é sempre um número par! Pois ao somarmos os graus dos vértices cada aresta é contada duas vezes.

/**
 *
 * @author Xprof_bruno -> jaaj-003_143_24_1_2027
 */
public class DigrafoInc {
    private int[][] matrizInc;
    private int numVertices;
    private int numArestas;
    
    public DigrafoInc(int nVertices/*, int nArestas*/){
        // Matriz de incidência: são matrizes nas quais as linhas estão associadas aos vértices e as colunas estão associadas às arestas.
        // Um elemento da linha i e coluna j é 1 se a aresta j é incidente ao vértice i e 0 caso contrário.
        matrizInc = new int[nVertices][nVertices];
        //Por termos que informar vértices de destino e origem, começamos sempre com o vértice enquanto modelo.
        //Não se informam o número de arestas [??], mas quantos vértices iremos trabalhar [*]
        numVertices = nVertices;
        //numArestas = nArestas;
        //Inicializando a matriz com o número zero 
        for(int linha=0; linha<nVertices; linha++){
            for(int coluna=0; coluna<nVertices; coluna++){
                matrizInc[linha][coluna]=0;
            }
        }
    }
    //2.Vértice de origem e destino
    public void adicionarAresta(int origem, int destino){
        matrizInc[origem-1][destino-1]+=1;
        matrizInc[destino-1][origem-1]+=1;
        this.numArestas++;
    }
    
    //Perguntar para o professor.
    public int testeConsultaGrau(int vertice){
        int grau=0;
        for(int coluna=0; coluna<this.numVertices; coluna++){
            for(int linha=0;linha<this.numVertices;linha++){
                grau+=matrizInc[vertice-1][vertice-1];
            }
            //grau+=matrizInc[vertice-1][coluna];
        }
        return grau;
    }
    //4.Determinar o grau, \\.. 5.Determinar o grau de entrada/saida
    public int grauEntrada(int vertice) {
        int grauEntrada = 0;
        for (int i = 0; i < numVertices; i++) {
            grauEntrada += matrizInc[i][vertice - 1];
        }
        return grauEntrada;
    }

    public int grauSaida(int vertice) {
        int grauSaida = 0;
        for (int j = 0; j < numVertices; j++) {
            grauSaida += matrizInc[vertice - 1][j];
        }
        return grauSaida;
    }
    //Extra. Método bônus para experimentar
    public int consultaGrauGrafo(){
        int grau=0;
        for(int linhas=0; linhas < numVertices; linhas++){
            for(int colunas=0; colunas < numVertices; colunas++){
                grau+=matrizInc[linhas][colunas];
            }
        }
        return grau;
    }

    //1.Número de vértices E arestas
    public int getNumArestas(){
        return this.numArestas;
    }
    public int getNumVertices(){
        return this.numVertices;
    }
    
    //3.Imprimir a matriz
    public void imprimirGrafo(){
        String representacao="";
        for(int linha=0; linha<this.numVertices;linha++){
            for(int coluna=0; coluna<this.numVertices; coluna++){
                representacao+=matrizInc[linha][coluna] + " ";
            }
            representacao+="\n";
        }
        JOptionPane.showMessageDialog(null,
                "Matriz de Incidência\n" + representacao);
    }
    public boolean grafoSimples(){
        int loop=0, arestaParalela=0;
        for(int linha=0; linha<this.numVertices;linha++){
            for(int coluna=0; coluna<this.numVertices; coluna++){
                if(linha==coluna && matrizInc[linha][coluna]>0){
                    loop+=1;
                }
                if(matrizInc[linha][coluna]>1){
                    arestaParalela+=1;
                }
            }
         }
        if(loop!=0 || arestaParalela!=0){
            return false;
        }
        else{
            return true;
        }
        
    }
    //7.Quantidade de arestas paralelas e laços,-> 7[Quem são esses vértices?]
    public String InformeMultigrafo(){
        int loops=0, arestaParalelas=0; StringBuilder sb = new StringBuilder("Arestas paralelas e laços:\n");
        for(int i=0; i<this.numVertices;i++){
            for(int j=0; j<this.numVertices; j++){
                if(i==j && matrizInc[i][j]>0){
                    loops+=1;
                    sb.append("Loop no vértice ").append(i + 1).append(" (").append(matrizInc[i][i]).append(")\n");
                }
                if(matrizInc[i][j]>1){
                    arestaParalelas+=1;
                    sb.append("Aresta paralela entre vértices ").append(i + 1).append(" e ").append(j + 1).append(" (").append(matrizInc[i][j]).append(")\n");
                }
            }
         }
        //if(loops!=0 || arestaParalelas!=0){
            sb.append("Total de laços: ").append(loops).append("\n");
            sb.append("Total de arestas paralelas: ").append(arestaParalelas).append("\n");
    
            return sb.toString();
        //}
    }
    //6.Solicitar_Vértice_Vizinhos
    public String Inc_vizinhos(int vertice) {
        StringBuilder sb = new StringBuilder();
        for (int j = 0; j < numVertices; j++) {
            if (matrizInc[vertice - 1][j] > 0) {
                sb.append(j + 1).append(" ");
            }
        }
        return sb.toString();
    }
    public String Inc_vizinhos_inverso(int vertice){ //Experimento de linha e coluna {entrada/saida} [?]
        StringBuilder sb = new StringBuilder(); for (int i=0;i<numVertices;i++){
            if (matrizInc[i][vertice-1]>0){ //E no caso de laços e paralelas...?
            sb.append(i+1).append(" ");}
        } return sb.toString();
    }
/*Exercício 2 - Matriz de Incidência de Grafos e Dígrafos (6 PONTOS)

X - 1.Número de vértices E arestas -
X - 2.Vértice de origem e destino --
X - 3.Imprimir a matriz ------------
X - 4.Determinar o grau, -----------
X - 6.Solicitar_Vértice_Vizinhos ---

X 5.Determinar o grau de entrada/saida (digrafo) X


X 7.Quantidade de arestas paralelas e laços, X
X -> 7[Quem são esses vértices?] ----------- X

Utilizar conceitos de POO, ou seja, usar classes, objetos e métodos*/
}