/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estruturagrafos;

/**
 *
 * @author Jade [0031432412027_"Moisés"] & Matheus Peixoto
 */

 //arquivo .zip do projeto
 import javax.swing.JOptionPane;

public class EstruturaGrafos {
    public static void main(String[] args) {
        int nVertices, op, vOrigem, vDestino, vertice, menu;
        //int nArestas;
        menu = Integer.parseInt(JOptionPane.showInputDialog("Deseja trabalhar com incidência [1] ou adjacência [2]?"));
        if(menu==1){
            if(Integer.parseInt(JOptionPane.showInputDialog("Teste automatizado [1] ou Teste manual [0]."))==1){
                // Não implementado
            } else{
/*ADJACENCIA

- Rotulação nos vértices de G.
- Complexidade = O(n^2).
- Uma tranposta equivale à inversão da orientação
- ...

INCIDENCIA
- Rotulação nos vértices e arestas de G.
- Complexidade = O(n*m).
- Toda coluna de A(G) posui 2 1's.
- Número de 1's = grau do vértice p/ linha.
- Vértice isolado [?]
- Paralelas correspondem a colunas idênticas
- Digrafos: Convergência (-1)/Divergência (1)*/
            nVertices = Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de vértices no dígrafo:"));
            //nArestas = Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de arestas no dígrafo:"));
            DigrafoInc digrafo = new DigrafoInc(nVertices/*, nArestas*/);
            do {
                op = Integer.parseInt(JOptionPane.showInputDialog(
                        "1 - Adicionar aresta ?\n" +
                        "2 - Imprimir matriz de incidência\n" +
                        "3 - Consultar grau de um vértice\n" +
                        "4 - Consultar o grau do grafo em si\n" +
                        "5 - Dígrafo simples ou multigrafo\n" +
                        "6 - Consultar vértices vizinhos\n" +
                        "7 - Consultar laços e arestas paralelas\n" +
                        "8 - Informar número de vértices e arestas\n" +
                        "9 - Experimentar vizinhos inverso\n" +
                        "0 - Sair\n" +
                        "Informe a opção desejada:"
                ));
                switch (op) {
                    case 1:
                        vOrigem = Integer.parseInt(JOptionPane.showInputDialog("Informe o vértice de origem:"));
                        vDestino = Integer.parseInt(JOptionPane.showInputDialog("Informe o vértice de destino:"));
                        digrafo.adicionarAresta(vOrigem, vDestino);
                        JOptionPane.showMessageDialog(null, "Aresta adicionada de " + vOrigem + " para " + vDestino);
                        break;
                    case 2:
                        digrafo.imprimirGrafo();
                        break;
                    case 3:
                        vertice = Integer.parseInt(JOptionPane.showInputDialog("Informe o vértice para consultar o grau:"));
                        JOptionPane.showMessageDialog(null,
                                "Grau de entrada: " + digrafo.grauEntrada(vertice) + "\n" +
                                "Grau de saída: " + digrafo.grauSaida(vertice)
                        );
                        break;
                    case 4:
                        JOptionPane.showMessageDialog(null,"Grau de grafo: " + digrafo.consultaGrauGrafo());
                        break;
                    case 5:
                        if (digrafo.grafoSimples()) {
                            JOptionPane.showMessageDialog(null, "O dígrafo é simples.");
                        } else {
                            JOptionPane.showMessageDialog(null, "O dígrafo possui laços ou arestas paralelas.");
                        }
                        break;
                    case 6:
                        vertice = Integer.parseInt(JOptionPane.showInputDialog("Informe o vértice para consultar os vizinhos:"));
                        JOptionPane.showMessageDialog(null, "Vértices vizinhos: " + digrafo.Inc_vizinhos(vertice));
                        break;
                    case 7:
                        JOptionPane.showMessageDialog(null, digrafo.InformeMultigrafo());
                        break;
                    case 8:
                        JOptionPane.showMessageDialog(null, "Vértices: " + digrafo.getNumVertices() + "\nArestas: " + digrafo.getNumArestas());
                        break;
                    case 9:
                        vertice = Integer.parseInt(JOptionPane.showInputDialog("Informe o vértice para consultar os vizinhos:"));
                        JOptionPane.showMessageDialog(null, "Vértices vizinhos: " + digrafo.Inc_vizinhos_inverso(vertice));
                        break;
                    case 0:
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opção inválida!");
                }

            } while(op!=0);}
        }
        else if (menu==2){
            // Informar o número de vértices
            nVertices = Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de vértices no dígrafo:"));

            // Criar o dígrafo
            DigrafoAdj digrafo = new DigrafoAdj(nVertices);

            do {
                op = Integer.parseInt(JOptionPane.showInputDialog(
                        "1 - Adicionar aresta\n" +
                        "2 - Imprimir matriz de adjacência\n" +
                        "3 - Consultar grau de um vértice\n" +
                        "4 - Dígrafo simples ou multigrafo\n" +
                        "5 - Consultar vértices vizinhos\n" +
                        "6 - Consultar laços e arestas paralelas\n" +
                        "7 - Informar número de vértices e arestas\n" +
                        "8 - Sair\n" +
                        "Informe a opção desejada:"
                ));

                switch (op) {
                    case 1:
                        vOrigem = Integer.parseInt(JOptionPane.showInputDialog("Informe o vértice de origem:"));
                        vDestino = Integer.parseInt(JOptionPane.showInputDialog("Informe o vértice de destino:"));
                        digrafo.adicionarAresta(vOrigem, vDestino);
                        JOptionPane.showMessageDialog(null, "Aresta adicionada de " + vOrigem + " para " + vDestino);
                        break;
                    case 2:
                        digrafo.imprimirMatrizAdjacencia();
                        break;
                    case 3:
                        vertice = Integer.parseInt(JOptionPane.showInputDialog("Informe o vértice para consultar o grau:"));
                        JOptionPane.showMessageDialog(null,
                                "Grau de entrada: " + digrafo.grauEntrada(vertice) + "\n" +
                                "Grau de saída: " + digrafo.grauSaida(vertice)
                        );
                        break;
                    case 4:
                        if (digrafo.digrafoSimples()) {
                            JOptionPane.showMessageDialog(null, "O dígrafo é simples.");
                        } else {
                            JOptionPane.showMessageDialog(null, "O dígrafo possui laços ou arestas paralelas.");
                        }
                        break;
                    case 5:
                        vertice = Integer.parseInt(JOptionPane.showInputDialog("Informe o vértice para consultar os vizinhos:"));
                        JOptionPane.showMessageDialog(null, "Vértices vizinhos: " + digrafo.vizinhos(vertice));
                        break;
                    case 6:
                        JOptionPane.showMessageDialog(null, digrafo.informarArestasParalelasELaços());
                        break;
                    case 7:
                        JOptionPane.showMessageDialog(null, digrafo.informarNumVerticesEArestas());
                        break;
                    case 8:
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opção inválida!");
                }
            }
            while (op != 8);
        }
    }
}
